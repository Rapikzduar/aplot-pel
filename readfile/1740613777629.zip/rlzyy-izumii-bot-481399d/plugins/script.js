const helper = {
  command: ['sc'],
  category: 'info',
  description: 'Original script bot',
  operate: async (ctx) => {
    await ctx.reply('Original Script: https://github.com/rlzyy/izumii-bot.git\n(This base is 100% made by *Rlzyy* If you claim this is mine and sell it, be prepared to bear the risk.)\n\n\n[ Thanks To ]\n- Telegraf & Module Creator\n- Rlzyy (Base Maker)\n- Muhammad Adriansyah\n -KyuuRzy\n- Naraa\n- XYZ Teams');
  },
  noPrefix: false,
  isOwner: false,
  isGroup: false,
  isPremium: false,
};

export default helper;
